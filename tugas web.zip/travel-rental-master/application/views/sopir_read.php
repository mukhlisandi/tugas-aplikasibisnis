<div class='col-lg-12'>
        <h2 style="margin-top:0px">Sopir Read</h2>
        <table class="table">
	    <tr><td>sopir_alamat</td><td><?php echo $sopir_alamat; ?></td></tr>
	    <tr><td>sopir_nama</td><td><?php echo $sopir_nama; ?></td></tr>
	    <tr><td>sopir_telpon</td><td><?php echo $sopir_telpon; ?></td></tr>
	    <tr><td>sopir_ktp</td><td><?php echo $sopir_ktp; ?></td></tr>
	    <tr><td>sopir_sim</td><td><?php echo $sopir_sim; ?></td></tr>
	    <tr><td>sopir_status</td><td><?php echo $sopir_status; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('sopir') ?>" class="btn btn-default">Cancel</button></td></tr>
	</table>
    </div>