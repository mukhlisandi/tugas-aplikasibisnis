<?php
//configure your database setting here
$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'ujian';
?>