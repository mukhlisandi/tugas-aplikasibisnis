<div class='col-lg-12'>
        <h2 style="margin-top:0px">Tarif Read</h2>
        <table class="table">
	    <tr><td width="200">PLAT NOMOR</td><td><?php echo $kendaraan_id; ?></td></tr>
	    <tr><td>TARIF PERHARI</td><td><?php echo $tarif_perhari; ?></td></tr>
	    <tr><td>TARIF OVERTIME</td><td><?php echo $tarif_overtime; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('tarif') ?>" class="btn btn-default">Cancel</button></td></tr>
	</table>
    </div>