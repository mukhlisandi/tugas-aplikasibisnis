<div class='col-lg-12'>
        <h2 style="margin-top:0px">Pelanggan Read</h2>
        <table class="table">
	    <tr><td>pelanggan_nama</td><td><?php echo $pelanggan_nama; ?></td></tr>
	    <tr><td>pelanggan_alamat</td><td><?php echo $pelanggan_alamat; ?></td></tr>
	    <tr><td>pelanggan_telpon</td><td><?php echo $pelanggan_telpon; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('pelanggan') ?>" class="btn btn-default">Cancel</button></td></tr>
	</table>
    </div>